#pragma once
#include <exception>
#include <iostream>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>

enum TokenClass {
    END,
    MINUS,
    PLUS,
    ASTERISK,
    OPENED_PARENTH,
    CLOSED_PARENTH,
    DOLLAR,
    NUM,
    ID
};

class Parser {
    private:
        std::vector<std::string> tokens_;
        std::stack<std::string> symbols_;
        std::unordered_map<std::string, std::unordered_map<std::string, std::string>> table_;
        int next_;

        void initStack();
        void initTable();
        bool isTerminal(const std::string &) const;
        void pushCarefully(const std::string &);
        void popCarefully();
        void printStack() const;
        std::string fetchNextSymbol();

    public:
        Parser(const std::vector<std::string> &);
        bool parse();
};
