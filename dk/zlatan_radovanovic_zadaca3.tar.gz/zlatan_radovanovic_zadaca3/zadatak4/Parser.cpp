#include "Parser.hpp"


Parser::Parser(const std::vector<std::string> &tokens) : next_{0} {
    tokens_ = std::move(tokens);
    tokens_.push_back("$");

    initStack();
    initTable();
}

void Parser::initStack() {
    symbols_.push("$");
    symbols_.push("E");
}

void Parser::initTable() {
    table_.insert({"E", {
        {"-", "TE'"},
        {"+", ""},
        {"*", ""},
        {"(", "TE'"},
        {")", ""},
        {"num", "TE'"},
        {"id", "AA"},
        {"$", ""},
    }});

    table_.insert({"E'", {
        {"-", "-TE'"},
        {"+", "+TE'"},
        {"*", ""},
        {"(", "FT'"},
        {")", "eps"},
        {"num", "FT'"},
        {"id", "FT'"},
        {"$", "eps"},
    }});

    table_.insert({"T", {
        {"-", "FT'"},
        {"+", ""},
        {"*", ""},
        {"(", "FT'"},
        {")", ""},
        {"num", "FT'"},
        {"id", "FT'"},
        {"$", ""},
    }});

    table_.insert({"T'", {
        {"-", "eps"},
        {"+", "eps"},
        {"*", "*FT'"},
        {"(", ""},
        {")", "eps"},
        {"num", ""},
        {"id", ""},
        {"$", "eps"},
    }});

    table_.insert({"F", {
        {"-", "-F"},
        {"+", ""},
        {"*", ""},
        {"(", "I"},
        {")", ""},
        {"num", "I"},
        {"id", "I"},
        {"$", ""},
    }});

    table_.insert({"I", {
        {"-", ""},
        {"+", ""},
        {"*", ""},
        {"(", "(E)"},
        {")", ""},
        {"num", "num"},
        {"id", "id"},
        {"$", ""},
    }});
}

bool Parser::isTerminal(const std::string &symbol) const {
    if (symbol == "E" || symbol == "E'" ||
        symbol == "T" || symbol == "T'" ||
        symbol == "F" || symbol == "I"  ||
        symbol == "'")
        return false;

    return true;
}

void Parser::pushCarefully(const std::string &rule) {
    if (rule.empty())
        throw std::logic_error("Wtf");

    if (rule == "num" || rule == "id" || rule == "eps") {
        symbols_.push(rule);
    } else {
        for (int i = rule.size() - 1; i >= 0; --i) { //DO NOT TRY THIS AT HOME
            symbols_.push(std::string{rule[i]});
        }
    }

}

std::string Parser::fetchNextSymbol() {
    std::string symbol;
    symbol = symbols_.top();
    symbols_.pop();

    if (!symbols_.empty() && symbols_.top() == "'") {
        symbol += "'";
        symbols_.pop();
    }

    return symbol;
}

void Parser::printStack() const {
    auto c = symbols_;

    std::cout << "Stack state: ";
    while (!c.empty()){
        std::cout << c.top();
        c.pop();
    }
    std::cout << std::endl;
}

void Parser::popCarefully() {
    printStack();
    symbols_.pop();

    if (!symbols_.empty() && symbols_.top() == "'") {
        symbols_.pop();
    }

    printStack();
}

bool Parser::parse() {
    std::string symbol;

    while (!symbols_.empty()) {
        symbol = fetchNextSymbol();
        // printStack();

        if (isTerminal(symbol)) {
            if (symbol == tokens_[next_]){
                next_++;
            } else {
                return false;
            }
        } else {
            const auto &row = table_.at(symbol);
            const auto &rule = row.at(tokens_[next_]);

            if (rule == "") {
                throw std::invalid_argument("Syntax error.");
            }

            if (rule == "eps") {
                continue;
            }

            pushCarefully(rule);
        }
    }

    return true;
}
