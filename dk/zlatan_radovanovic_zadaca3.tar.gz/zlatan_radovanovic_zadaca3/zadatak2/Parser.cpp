#include "Parser.hpp"


Parser::Parser(const std::vector<int> &tokens) :
    tokens_{tokens}, currentIndex_{0} {
    len_ = tokens.size();
}

bool Parser::parse() {
    bool ret = start();
    if (currentIndex_ < len_)
        ret = false;

    return ret;
}

bool Parser::eps() {
    return true;
}

bool Parser::start() {
    int backupIndex = currentIndex_;
    return v() || (currentIndex_ = backupIndex, s()) || (currentIndex_ = backupIndex, m());
}

bool Parser::v() {
    return terminal(OPEN_BRACE) && vp() && terminal(CLOSED_BRACE);
}

bool Parser::vp() {
    int backupIndex = currentIndex_;
    return (s() && vp()) || (currentIndex_ = backupIndex, m() && vp()) || (currentIndex_ = backupIndex, eps());
}

bool Parser::s() {
    return terminal(OPEN_BRACKET) && sp() && terminal(CLOSED_BRACKET);
}

bool Parser::sp() {
    int backupIndex = currentIndex_;
    return (m() && sp()) || (currentIndex_ = backupIndex, eps());
}

bool Parser::m() {
    return terminal(OPEN_PARENTH) && terminal(CLOSED_PARENTH);
}

bool Parser::terminal(int tokenClass) {
    if (currentIndex_ >= len_)
        return false;
    return (tokenClass == tokens_[currentIndex_++]);
}
