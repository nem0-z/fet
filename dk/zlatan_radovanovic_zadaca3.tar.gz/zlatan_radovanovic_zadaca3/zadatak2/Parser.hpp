#pragma once
#include <vector>

class Parser{
    private:
        std::vector<int> tokens_;
        int currentIndex_;
        int len_;

    public:
        Parser(const std::vector<int> &);
        bool parse();
        bool start();
        bool v();
        bool vp();
        bool s();
        bool sp();
        bool m();
        bool eps();
        bool terminal(int);
};

enum TokenClass {
    NEWLINE,
    OPEN_PARENTH,
    OPEN_BRACKET,
    OPEN_BRACE,
    CLOSED_PARENTH,
    CLOSED_BRACKET,
    CLOSED_BRACE
};
