#pragma once

enum TokenClass {
  ID = 1,
  INTEGER,
  OP_ASSIGN,
  OP_PLUS,
  OP_MINUS,
  OP_MUL,
  OP_DIV,
  LEFT_PAREN,
  RIGHT_PAREN,
  UNKNOWN
};
