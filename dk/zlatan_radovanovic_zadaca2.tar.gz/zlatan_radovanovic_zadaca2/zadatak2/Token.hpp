#pragma once

#include <string>

enum TokenClass {
  KEYWORD = 1,
  ID,
  ARITH_OP,
  RELAT_OP,
  LOGIC_OP,
  MISC_OP,
  INT,
  STRING,
  COMMENT,
  OPEN_PARENTH,
  CLOSED_PARENTH,
  OPEN_BRACKET,
  CLOSED_BRACKET,
  OPEN_BRACE,
  CLOSED_BRACE,
  COMMA,
  COLON,
  SEMICOLON
};

class Token {
  private:
  int tokenClass_;

  public:
  Token(int tokenClass) : 
    tokenClass_{tokenClass} {}

  std::string mapClassToString() const {
    switch(tokenClass_) {
      case KEYWORD:
        return "KEYWORD";
      case ID:
        return "ID";
      case ARITH_OP:
        return "ARITH_OP";
      case RELAT_OP:
        return "RELAT_OP";
      case LOGIC_OP:
        return "LOGIC_OP";
      case MISC_OP:
        return "MISC_OP";
      case INT:
        return "INT";
      case STRING:
        return "STRING";
      case COMMENT:
        return "COMMENT";
      case OPEN_PARENTH:
        return "OPEN_PARENTH";
      case CLOSED_PARENTH:
        return "CLOSED_PARENTH";
      case OPEN_BRACKET:
        return "OPEN_BRACKET";
      case CLOSED_BRACKET:
        return "CLOSED_BRACKET";
      case OPEN_BRACE:
        return "OPEN_BRACE";
      case CLOSED_BRACE:
        return "CLOSED_BRACE";
      case COMMA:
        return "COMMA";
      case COLON:
        return "COLON";
      case SEMICOLON:
        return "SEMICOLON";
    }

    return "UNKNOWN_TOKEN";
  }
};
