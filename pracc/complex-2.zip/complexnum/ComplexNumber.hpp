#pragma once
#include <cmath>
#include <iostream>

class ComplexNumber {
  public:
  // Postavlja realni i imaginarni dio kompleksnog broja na 0.
  ComplexNumber();
  ComplexNumber(const ComplexNumber& obj);
  ComplexNumber(double re, double im = 0);
  ComplexNumber& operator=(const ComplexNumber& obj);
  // z3 = z1 + z2
  // z3 = (2 + 3i) + (5 + 7i) = 7 + 10i
  ComplexNumber operator+(const ComplexNumber& obj) const;
  // z2 = z1 + 10
  // z2 = (5 + 2i) + 10 = 15 + 2i
  ComplexNumber operator+(double broj) const;
  ComplexNumber operator-(const ComplexNumber& obj) const;
  ComplexNumber operator-(double broj) const;
  ComplexNumber operator*(const ComplexNumber& obj) const;
  ComplexNumber operator*(double broj) const;
  ComplexNumber operator/(double broj) const;
  // z1 = 2 + 3i
  // z2 = 3 + 4i
  // z2 += z1 = 5 + 7i
  ComplexNumber& operator+=(const ComplexNumber& obj);
  ComplexNumber& operator-=(const ComplexNumber& obj);
  ComplexNumber& operator*=(const ComplexNumber& obj);
  ComplexNumber& operator/=(const ComplexNumber& obj);
  // Prefix forma inkrementa, na realni dio dodaje 1
  ComplexNumber& operator++();
  // Postfix forma inkrementa
  ComplexNumber operator++(int);
  // Prefix forma dekrementa, od realnog dijela oduzima 1.
  ComplexNumber& operator--();
  // Postfix forma dekrementa
  ComplexNumber operator--(int);
  bool operator==(const ComplexNumber& obj) const;
  bool operator!=(const ComplexNumber& obj) const;
  double getRe() const;
  double getIm() const;
  void setRe(double x);
  void setIm(double y);
  // Racunanje modula kompleksnog broja
  double modul() const;
  ~ComplexNumber();

  private:
  double re_;
  double im_;
};

std::ostream & operator<<(std::ostream &os, const ComplexNumber &obj);
