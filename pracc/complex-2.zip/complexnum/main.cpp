#include "ComplexNumber.hpp"

int main (int argc, char *argv[]) {
    ComplexNumber c1;
    std::cout << c1 << std::endl;

    ComplexNumber c2(c1);
    std::cout << c2 << std::endl;

    ComplexNumber c3(5, 6);
    ComplexNumber c4(4);
    std::cout << c3 << std::endl;
    std::cout << c4 << std::endl;
    c2 = c3;
    std::cout << c2 << std::endl;

    ComplexNumber z1(2, 3);
    ComplexNumber z2(5, 7);
    ComplexNumber z3 = z1 + z2;
    std::cout << z3 << std::endl;

    ComplexNumber z4 = z1 * z3;
    std::cout << z4 << std::endl;
    ++z4;
    std::cout << z4 << std::endl;
    --z4;
    std::cout << z4 << std::endl;

    z1 += z2;
    std::cout << z1 << std::endl;

    std::cout << (z1 == z2) << std::endl;
    std::cout << (z1 != z2) << std::endl;

    std::cout << z1.modul() << std::endl;

    return 0;
}
