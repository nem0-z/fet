#include "ComplexNumber.hpp"

ComplexNumber::ComplexNumber() : re_(0), im_(0) {}

ComplexNumber::ComplexNumber(const ComplexNumber &obj) {
    re_ = obj.getRe();
    im_ = obj.getIm();
}

ComplexNumber::ComplexNumber(double re, double im) : re_(re), im_(im) {}

ComplexNumber & ComplexNumber::operator=(const ComplexNumber &obj) {
    re_ = obj.getRe();
    im_ = obj.getIm();
    return *this;
}

ComplexNumber ComplexNumber::operator+(const ComplexNumber &obj) const {
    return ComplexNumber(re_ + obj.getRe(), im_ + obj.getIm());
}

ComplexNumber ComplexNumber::operator+(double broj) const {
    return ComplexNumber(re_ + broj, im_);
}

ComplexNumber ComplexNumber::operator-(const ComplexNumber &obj) const {
    return ComplexNumber(re_ - obj.getRe(), im_ - obj.getIm());
}

ComplexNumber ComplexNumber::operator-(double broj) const {
    return ComplexNumber(re_ - broj, im_);
}

ComplexNumber ComplexNumber::operator*(const ComplexNumber &obj) const {
    return ComplexNumber(re_ * obj.getRe() - im_ * obj.getIm(), re_ * obj.getIm() + im_ * obj.getRe());
}

ComplexNumber ComplexNumber::operator*(double broj) const {
    return ComplexNumber(re_ * broj, im_ * broj);
}

ComplexNumber ComplexNumber::operator/(double broj) const {
    return ComplexNumber(re_ / broj, im_ / broj);
}

ComplexNumber& ComplexNumber::operator+=(const ComplexNumber &obj) {
    re_ += obj.getRe();
    im_ += obj.getIm();
    return *this;
}

ComplexNumber& ComplexNumber::operator-=(const ComplexNumber &obj) {
    re_ -= obj.getRe();
    im_ -= obj.getIm();
    return *this;
}

ComplexNumber& ComplexNumber::operator*=(const ComplexNumber &obj) {
    re_ = re_ * obj.getRe() - im_ * obj.getIm();
    im_ = re_ * obj.getIm() + im_ * obj.getRe();
    return *this;
}

ComplexNumber& ComplexNumber::operator/=(const ComplexNumber &obj) {
    re_ = (re_ * obj.getRe() + im_ * obj.getIm()) / (obj.getRe() * obj.getRe() + obj.getIm() * obj.getIm());
    im_ = (im_ * obj.getRe() - re_ * obj.getIm()) / (obj.getRe() * obj.getRe() + obj.getIm() * obj.getIm());
    return *this;
}

ComplexNumber& ComplexNumber::operator++() {
    ++re_;
    return *this;
}

ComplexNumber ComplexNumber::operator++(int) {
    ComplexNumber tmp;
    ++re_;
    return tmp;
}

ComplexNumber& ComplexNumber::operator--() {
    --re_;
    return *this;
}

ComplexNumber ComplexNumber::operator--(int) {
    ComplexNumber tmp;
    --re_;
    return tmp;
}

bool ComplexNumber::operator==(const ComplexNumber &obj) const {
    return re_ == obj.getRe() && im_ == obj.getIm();
}

bool ComplexNumber::operator!=(const ComplexNumber &obj) const {
    return re_ != obj.getRe() || im_ != obj.getIm();
}

double ComplexNumber::getRe() const {
    return re_;
}

double ComplexNumber::getIm() const {
    return im_;
}

void ComplexNumber::setRe(double x) {
    re_ = x;
}

void ComplexNumber::setIm(double x) {
    im_ = x;
}

double ComplexNumber::modul() const {
    return std::sqrt(re_ * re_ + im_ * im_);
}

ComplexNumber::~ComplexNumber() {

}

std::ostream & operator<<(std::ostream &os, const ComplexNumber &obj) {
    if (obj.getIm() >= 0)
        os << "Z = " << obj.getRe() << " + " << obj.getIm() << "i";
    else
        os << "Z = " << obj.getRe() << " - " << std::abs(obj.getIm()) << "i";

    return os;
}
