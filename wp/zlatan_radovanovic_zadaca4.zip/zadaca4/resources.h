#define EDIT_A 101
#define EDIT_B 102
#define EDIT_C 103
#define EDIT_D 104
#define EDIT_XMAX 105
#define EDIT_YMAX 106
#define EQ_LIST 107
#define IDB_0 108
#define IDB_CRTAJ 109
#define MENU_EXIT 110
#define MENU_ABOUT 111
#define IDC_CURSOR 112
#define IDI_ICON 113


